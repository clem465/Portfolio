  const body = document.body;

  document.getElementById("themeToggle").addEventListener("click", () => {
    body.classList.toggle("dark-mode");
    const image1 = document.getElementById("logo");
    const image2 = document.getElementById("ProfilePicture");
    const image3 = document.getElementById("darkmode");
    if (body.classList.contains("dark-mode")) {
        image1.src = "/images/logo2.png"
        image2.src = "/images/photo2.png"
        image3.src = "/images/light.png"
    } else {
        image1.src = "/images/logo.png"
        image2.src = "/images/photo.png"
        image3.src = "/images/dark.png"
    }
  });
